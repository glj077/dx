package com.example.dx_4g.funclass;

import android.widget.ImageView;
import android.widget.TextView;
//listview优化显法数据缓存
public class ViewHolder {
    TextView dx_status;
    ImageView dx_icon;
    TextView  dx_name;
    TextView dx_ip;
}
