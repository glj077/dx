package com.example.dx_4g.funclass;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolderReg {
    TextView reg_name;
    ImageView reg_icon;
    TextView  reg_value;
}
