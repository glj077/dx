package com.example.dx_4g.funclass;

import android.widget.TextView;

public class ViewHolderAlarm {
    TextView alarm_name;
    TextView alarm_count;
}
