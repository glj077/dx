package com.example.dx_4g;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dx_4g.funclass.BaseActivity;
import com.example.dx_4g.funclass.httpopenException;

public class Main4Activity extends BaseActivity implements View.OnClickListener {

    TextView mTextLeftDate;
    TextView mTextLeftWeek;

    TextView mTextRightDate;
    TextView mTextRightWeek;

    TextView mTextMinRange;
    TextView mTextMaxRange;

    CalendarView mCalendarView;

    int dateselectsign=0;

    @Override
    protected int getLayoutId() {
        return R.layout.alendarview;
    }

    @SuppressLint("ResourceType")
    @Override
    protected void initView() {


        mTextLeftDate = findViewById(R.id.tv_left_date);
        mTextLeftWeek = findViewById(R.id.tv_left_week);
        mTextRightDate = findViewById(R.id.tv_right_date);
        mTextRightWeek = findViewById(R.id.tv_right_week);

        mTextMinRange = findViewById(R.id.tv_min_range);
        mTextMaxRange = findViewById(R.id.tv_max_range);

        mCalendarView = findViewById(R.id.calendarView);


        findViewById(R.id.tv_commit).setOnClickListener(this);


        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String selectdate=(month+1)+"月"+dayOfMonth+"日";
                dateselectsign=dateselectsign+1;
                if (dateselectsign==1) {
                    mTextLeftDate.setText(selectdate);
                    mTextRightDate.setText(null);
                }else{
                    mTextRightDate.setText(selectdate);
                    dateselectsign=0;
                }
            }
        });




    }

    @Override
    protected void initData() throws httpopenException {

    }


    @Override
    public void onClick(View v) {

    }
}
