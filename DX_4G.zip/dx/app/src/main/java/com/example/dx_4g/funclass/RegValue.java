package com.example.dx_4g.funclass;

public class RegValue {
    private int addr;
    private int value;

    public int getReg_addr(){return addr;}
    public int getReg_value(){return value;}
    public void setReg_addr(int addr){this.addr=addr;}
    public void setReg_value(int value){this.value=value;}
}
