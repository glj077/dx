package com.example.dx_4g.funclass;

public interface RegCallBackListener {
    void setRegPosition(int regPosition);
}
